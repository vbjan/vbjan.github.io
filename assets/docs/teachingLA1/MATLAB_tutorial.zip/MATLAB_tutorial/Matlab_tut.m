% MATLAB TUTORIAL

clear % deletes all variables in workspace 
clc % clears console
disp('hello world') % prints string in console

%% Variablen deklarieren
% Skalare deklarieren
x = 4;

%% Vektoren deklarieren
v1 = [1,2,3]; % Zeilenvektor
v2 = [1       % Spaltenvektor
      2
      3];

%% Matrix deklarieren
A = [1,2,3; 1,0,0; 0,1,0];

B = [1 2 3 
    1 0 0
    0 1 0];

%% Variablen in Konsole ausgeben

x, v1

%% Spalte aus Matrix lesen:

A(:,1)

%% Komponenten ver�ndern
v1
v1(1) = 0
A(2,2) = 1
A(2,2) = 0

%% "Gr��e" von Variablen

size_A = size(A) % gibt Anzahl Zeilen und Spalten zur�ck
size_v2 = size(v2)

%% Operationen

% Matrixmultiplikation
A*v2
A*B
A+B

%% Inverse berechnen
A_inv = inv(A)

%% L�sen von Gleichungssystem

% L�sug f�r A*x=v2
x = A\v2

% L�sung f�r x*A = v1
x = v1/A

